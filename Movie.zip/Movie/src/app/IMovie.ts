import { Url } from 'url';

export interface IMovie {
    mylist: [
        {
          title: string,
          id: number,
          img: Url
        }
      ],
      recommendations: [
        {
            title: string,
            id: number,
            img: Url
        }
      ]

  }