import { Component, OnInit } from '@angular/core';
import { MovieService } from './../movie.service';

@Component({
  selector: 'app-movie',
  templateUrl: './movie.component.html',
  styleUrls: ['./movie.component.css']
})
export class MovieComponent implements OnInit {

  movies : any = {};
  errorMsg : any;

  constructor(private movieService: MovieService) {}
  
  ngOnInit() {
    this.movieService.getMovie()
        .subscribe(data => this.movies = data,
                  error => this.errorMsg = error);
  }

  addMovie(movie){
    this.movies.mylist.push(movie);
    let index = this.movies.recommendations.indexOf(movie);
    this.movies.recommendations.splice(index, 1);
  }

  deleteMovie(movie){
    let index = this.movies.mylist.indexOf(movie);
    this.movies.mylist.splice(index, 1);
  }

}
